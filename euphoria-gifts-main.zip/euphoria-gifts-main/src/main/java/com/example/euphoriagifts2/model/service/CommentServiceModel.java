package com.example.euphoriagifts2.model.service;

public class CommentServiceModel {
    private Long giftId;
    private String message;
    private String creator;

    public CommentServiceModel() {
    }

    public Long getGiftId() {
        return giftId;
    }

    public void setGiftId(Long giftId) {
        this.giftId = giftId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
}
