package com.example.euphoriagifts2.service;

import com.example.euphoriagifts2.model.entity.RoleEntity;
import com.example.euphoriagifts2.model.entity.enums.RoleNameEnum;

public interface RoleService {
}
