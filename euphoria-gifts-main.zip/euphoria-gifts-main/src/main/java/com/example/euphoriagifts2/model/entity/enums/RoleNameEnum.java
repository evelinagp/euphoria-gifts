package com.example.euphoriagifts2.model.entity.enums;

public enum RoleNameEnum {
    USER, ADMIN;
}
