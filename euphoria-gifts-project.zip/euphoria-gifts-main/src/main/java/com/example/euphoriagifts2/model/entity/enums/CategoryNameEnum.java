package com.example.euphoriagifts2.model.entity.enums;

public enum CategoryNameEnum {
    HOME, KITCHEN, WOMEN, MEN, OCCASIONS, OTHERS
}
