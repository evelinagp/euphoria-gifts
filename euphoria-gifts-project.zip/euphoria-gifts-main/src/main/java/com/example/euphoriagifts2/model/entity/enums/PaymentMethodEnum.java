package com.example.euphoriagifts2.model.entity.enums;

public enum PaymentMethodEnum {
    CASH, BANK, PAYPAL;
}
